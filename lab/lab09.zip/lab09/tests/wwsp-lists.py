test = {
  'name': 'What Would Scheme Print?',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          scm> (cons 1 2)
          2d28ec62cafd4f8193ed195771360ba3
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (cons 1 (cons 2 nil))
          437da7fcde2856663fa0002aab0f0b14
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (car (cons 1 (cons 2 nil)))
          d912fc844d1dbaeea8a84b3ec8b315bc
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (cdr (cons 1 (cons 2 nil)))
          4c4505b119f53fac68e1f7117354f1e1
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (list 1 2 3)
          7585771ecc8eac10b0735a645ecb8a79
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (list 1 (cons 2 3))
          e01f96b8c839e7c2096a639b6d420723
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> '(1 2 3)
          7585771ecc8eac10b0735a645ecb8a79
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> '(2 . 3)
          54a1bf77dcb4d871279707fddceb2d17
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> '(2 . (3))               ; Recall dot notation rule
          812fc8d3741aa2f642b208f2d531234d
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (eq? '(1 . (2 . 3)) (cons 1 (cons 2 (cons 3 nil))))
          f2bf0507fb265c0e11f3ac62de7d23dd
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (eq? '(1 . (2 . 3)) (cons 1 (cons 2 3)))
          7ac1449159889a2d4fb8c48a1bb9fe87
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (eq? '(1 . (2 . 3)) (list 1 (cons 2 3)))
          f2bf0507fb265c0e11f3ac62de7d23dd
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          scm> (cons 1 '(list 2 3))     ; Recall quoting
          826da030368e185a23a1a70897995e88
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': True,
      'setup': r"""
      
      """,
      'teardown': '',
      'type': 'scheme'
    }
  ]
}