.read sp16data.sql
.read fa15data.sql

-- Q2
CREATE TABLE obedience AS
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q3
CREATE TABLE smallest_int AS
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q4
CREATE TABLE greatstudents AS
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q5
CREATE TABLE matchmaker AS
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q6
CREATE TABLE fa15favnum AS
  SELECT "Favorite number from last semester";

CREATE TABLE fa15favpets AS
  SELECT "Top 10 pets last semester";

CREATE TABLE sp16favpets AS
  SELECT "Top 10 pets this semester";

CREATE TABLE sp16dragon AS
  SELECT "Number of people whose favorite pet is dragon";

CREATE TABLE sp16alldragons AS
  SELECT "Number of people whose favorite pet is some type of dragon";

CREATE TABLE obedienceimage AS
  SELECT "Number of obedient students who picked each image";

-- Q7
CREATE TABLE pairs AS
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

