.read lab12.sql

-- Q7
CREATE TABLE smallest_int_count AS
  select "REPLACE THIS LINE WITH YOUR SOLUTION";
