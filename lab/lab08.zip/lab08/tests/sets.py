test = {
  'name': 'Sets',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> a = [1, 1, 2, 2, 3, 3]
          >>> a = set(a)
          >>> len(a)
          a6a221ff20ce085ab4bedaca5044f971
          # locked
          >>> sorted(a)
          37397c3bae02dfdccc0cc2268dc87f82
          # locked
          >>> a.add(4)
          >>> a.add(4)
          >>> a.remove(4)
          >>> 4 in a
          9b87ee740b72a262114634ab6b9e401e
          # locked
          >>> a = {1, 4, 12, 1000}
          >>> sum(a)
          c5edcc4809728b760e4c77d952fb9af8
          # locked
          >>> b = {1, 2, 4}
          >>> sorted(a.intersection(b))
          2ddd53cd4eba7a98047bab7dbd40ecec
          # locked
          >>> sorted(a & b)
          2ddd53cd4eba7a98047bab7dbd40ecec
          # locked
          >>> sorted(a.union(b))
          73e03aaf46c5446c360c9507889e588e
          # locked
          >>> sorted(a | b)
          73e03aaf46c5446c360c9507889e588e
          # locked
          >>> sorted(a - b)
          2d802ff4ed389aaf0f23773ca4c9d602
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}