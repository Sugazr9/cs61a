test = {
  'name': 'Sevens',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> x = [1, 3, [5, 7], 9] # Write the code that indexes into x to output the 7
          465d433fff9ce95251e51d56faba3722
          # locked
          >>> x = [[7]] # Write the code that indexes into x to output the 7
          0629c5f0105aacca6217ba2ad53960dd
          # locked
          >>> x = [1, [2, [3, [4, [5, [6, [7]]]]]]] # Write the code that indexes into x to output the 7
          c6b82714dac808f27c9a27d521aaaa6a
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}