test = {
  'name': 'What Would Scheme Print?',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'answer': '29ff3ddf5f10e95dac7c4b16287b1235',
          'choices': [
            '(() (1 . 2))',
            '(() 1 . 2)',
            '(() 1)',
            '(() . 1)',
            '((1 . 2) . 1)',
            'Error'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          scm> (define lst (list () '(1 . 2) '(1 2 . (3))))
          lst
          scm> (cons (car lst) (car (cdr lst)))
          _______
          """
        },
        {
          'answer': '4febe839e55fb8f19ec15e11d74f6eb0',
          'choices': [
            '(2)',
            '((2))',
            '(2 3)',
            '((2 3))',
            '((2 3 1) . 2)',
            '(1 1 . 2)',
            'Error'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          scm> (cons (cdr (car (cdr lst))) (car lst))
          _______
          """
        },
        {
          'answer': 'b543829469555fc227b7eb426f3160d4',
          'choices': [
            '(((1 . 2) (1 2 3)))',
            '(() ((1 . 2) (1 2 3)))',
            '((1 . 2) (1 2 3))',
            'Error'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          scm> (list (car lst) (cdr lst))
          _______
          """
        },
        {
          'answer': '487121d6803c52fa040199f170435dc6',
          'choices': [
            '(((1 . 2) (1 2 3)))',
            '(() ((1 . 2) (1 2 3)))',
            '((1 . 2) (1 2 3))',
            'Error'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          scm> (append (car lst) (cdr lst))
          _______
          """
        },
        {
          'answer': '6bc83b57f01142a07862c9fd6e64a1f2',
          'choices': [
            '(((1 . 2) (1 2 3)))',
            '(() ((1 . 2) (1 2 3)))',
            '((1 . 2) (1 2 3))',
            'Error'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          scm> (cons (cdr lst) (car lst))
          _______
          """
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}